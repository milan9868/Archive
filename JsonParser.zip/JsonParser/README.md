# JSON Parser Project

# Compile the main program
make
./program <json_file> "<expression>"

# Example
./program 1.json "a.b"

# Compile and run tests
make test
./test_program
